import type { Config } from "tailwindcss";
const config: Config = { content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"], theme: { extend: { colors: { ink: "#07111f", panel: "#0d1b2b", emerald: "#18c58b", muted: "#8ea2b9" }, fontFamily: { sans: ["Arial", "sans-serif"] } } }, plugins: [] };
export default config;