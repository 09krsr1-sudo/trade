'use client';
import { useEffect, useRef } from "react";
import { createChart, ColorType, CandlestickSeries, type UTCTimestamp } from "lightweight-charts";

export default function MarketChart() {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!host.current) return;
    const chart = createChart(host.current, {
      height: 320, layout: { background: { type: ColorType.Solid, color: "#0d1b2b" }, textColor: "#8ea2b9" },
      grid: { vertLines: { color: "#17283a" }, horzLines: { color: "#17283a" } },
      rightPriceScale: { borderColor: "#26384b" }, timeScale: { borderColor: "#26384b", timeVisible: true },
      crosshair: { vertLine: { color: "#18c58b", labelBackgroundColor: "#087b59" }, horzLine: { color: "#18c58b", labelBackgroundColor: "#087b59" } }
    });
    const series = chart.addSeries(CandlestickSeries, {
      upColor: "#18c58b", downColor: "#ff647c", borderUpColor: "#18c58b", borderDownColor: "#ff647c",
      wickUpColor: "#18c58b", wickDownColor: "#ff647c"
    });
    const now = Math.floor(Date.now() / 1000);
    let price = 2640;
    const data = Array.from({length: 80}, (_, i) => {
      const open = price; const move = (Math.sin(i * .73) + Math.cos(i * .31)) * 2.8;
      const close = open + move; const high = Math.max(open, close) + 1.5 + (i % 3);
      const low = Math.min(open, close) - 1.3 - (i % 4) * .3; price = close;
      return { time: (now - (79 - i) * 3600) as UTCTimestamp, open, high, low, close };
    });
    series.setData(data); chart.timeScale().fitContent();
    const resize = () => { if (host.current) chart.applyOptions({ width: host.current.clientWidth }); };
    resize(); window.addEventListener("resize", resize);
    return () => { window.removeEventListener("resize", resize); chart.remove(); };
  }, []);
  return <div ref={host} className="w-full" aria-label="رسم شموع توضيحي للذهب" />;
}