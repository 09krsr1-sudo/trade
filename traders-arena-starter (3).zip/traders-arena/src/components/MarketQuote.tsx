"use client";
import { useState } from "react";
import { RefreshCw, RadioTower } from "lucide-react";
type Quote = { symbol: string; price?: number; available: boolean; source: string | null; message?: string; updatedAt: string | null };
export default function MarketQuote({ symbol = "XAU/USD" }: { symbol?: string }) {
 const [quote, setQuote] = useState<Quote | null>(null);
 const [loading, setLoading] = useState(false);
 async function refresh() {
   setLoading(true);
   try { const r = await fetch(`/api/market/quote?symbol=${encodeURIComponent(symbol)}`, { cache: "no-store" }); const data = await r.json(); setQuote(data); }
   catch { setQuote({ symbol, available: false, source: null, message: "تعذر الاتصال بخدمة الأسعار.", updatedAt: null }); }
   finally { setLoading(false); }
 }
 return <div className="rounded-xl border border-white/10 bg-white/[.025] p-4">
  <div className="flex flex-wrap items-center justify-between gap-3"><div><div className="flex items-center gap-2 text-sm font-semibold"><RadioTower size={15} className="text-emerald"/> فحص السعر المباشر · {symbol}</div><p className="mt-1 text-xs text-muted">يُعرض السعر فقط عند نجاح الاتصال بمزود البيانات.</p></div><button className="btn text-xs" onClick={refresh} disabled={loading}><RefreshCw size={14} className={loading ? "animate-spin" : ""}/>{loading ? "جارٍ الفحص" : "جلب السعر"}</button></div>
  {quote && <div className="mt-4 border-t border-white/5 pt-3">{quote.available && quote.price !== undefined ? <><div className="text-2xl font-bold text-emerald">{quote.price.toLocaleString("en-US", { maximumFractionDigits: 6 })}</div><div className="mt-1 text-xs text-muted">المصدر: {quote.source} · التحديث: {quote.updatedAt ? new Date(quote.updatedAt).toLocaleString("ar-IQ") : "غير متاح"}</div></> : <p className="text-sm leading-6 text-amber-100">{quote.message || "لا توجد بيانات متاحة."}</p>}</div>}
 </div>;
}
