import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
const ALLOWED = new Set(["XAU/USD", "XAG/USD", "EUR/USD", "GBP/USD", "BTC/USD", "ETH/USD", "WTI", "DXY", "SPX", "NDX", "DJI"]);

export async function GET(request: NextRequest) {
  const symbol = (request.nextUrl.searchParams.get("symbol") || "").toUpperCase();
  if (!ALLOWED.has(symbol)) {
    return NextResponse.json({ error: "رمز الأصل غير مدعوم." }, { status: 400 });
  }
  const apiKey = process.env.TWELVEDATA_API_KEY;
  if (!apiKey) {
    return NextResponse.json({
      symbol,
      available: false,
      source: null,
      message: "لم يتم إعداد مزود أسعار مباشر. لا توجد أسعار حقيقية متاحة.",
      updatedAt: null,
    }, { status: 503 });
  }

  try {
    const url = new URL("https://api.twelvedata.com/price");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("apikey", apiKey);
    const response = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error(`Provider HTTP ${response.status}`);
    const payload = await response.json();
    const price = Number(payload.price);
    if (!Number.isFinite(price) || price <= 0 || payload.status === "error") {
      return NextResponse.json({ symbol, available: false, source: "Twelve Data", message: payload.message || "لم يرجع مزود البيانات سعرًا صالحًا لهذا الأصل.", updatedAt: null }, { status: 502 });
    }
    return NextResponse.json({ symbol, price, available: true, source: "Twelve Data", updatedAt: new Date().toISOString() }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ symbol, available: false, source: "Twelve Data", message: "تعذر جلب السعر حاليًا. تحقق من المفتاح والخطة ودعم الرمز لدى المزود.", updatedAt: null }, { status: 502 });
  }
}
