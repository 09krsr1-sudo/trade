import Link from "next/link";
import { ArrowDownLeft, ArrowUpLeft, ArrowUpRight, BarChart3, BellRing, ChevronLeft, CircleHelp, Clock3, Gem, Newspaper, Sparkles, TrendingUp, Wallet } from "lucide-react";
import Shell from "@/components/Shell";
import MarketChart from "@/components/MarketChart";
import ProviderStatus from "@/components/ProviderStatus";

const assets = [
 {name:"الذهب",symbol:"XAU/USD",price:"2,643.80",change:"+0.84%",up:true,color:"gold",spark:"▁▂▃▂▄▅▃▆"},
 {name:"اليورو / الدولار",symbol:"EUR/USD",price:"1.08420",change:"+0.16%",up:true,spark:"▃▂▄▃▅▄▆▅"},
 {name:"الفضة",symbol:"XAG/USD",price:"31.482",change:"−0.27%",up:false,spark:"▆▅▆▄▃▄▂▃"},
 {name:"البيتكوين",symbol:"BTC/USD",price:"67,420.00",change:"+1.92%",up:true,spark:"▂▃▂▄▅▄▆▇"},
 {name:"مؤشر الدولار",symbol:"DXY",price:"104.18",change:"−0.12%",up:false,spark:"▆▅▄▅▃▄▃▂"},
 {name:"النفط الخام",symbol:"WTI",price:"78.62",change:"+0.31%",up:true,spark:"▂▃▄▃▅▄▅▆"},
 {name:"ناسداك 100",symbol:"NDX",price:"19,860.4",change:"+0.63%",up:true,spark:"▁▂▃▄▃▅▆▇"},
 {name:"الإيثيريوم",symbol:"ETH/USD",price:"3,510.80",change:"−0.44%",up:false,spark:"▇▆▅▆▄▅▃▂"}
];
const news = [
 {tag:"الذهب",time:"منذ 18 دقيقة",title:"الأسواق تترقب بيانات التضخم الأمريكية وتأثيرها في توقعات الفائدة",color:"text-amber-200"},
 {tag:"الفوركس",time:"منذ 42 دقيقة",title:"الدولار يتحرك ضمن نطاق محدود قبل صدور بيانات اقتصادية مهمة",color:"text-sky-300"},
 {tag:"العملات الرقمية",time:"منذ ساعة",title:"تقلبات العملات الرقمية تعيد التركيز إلى مستويات الدعم الرئيسية",color:"text-violet-300"}
];
export default function HomePage() {
 return <Shell>
  <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
   <div><div className="mb-2 flex items-center gap-2 text-xs text-emerald"><span className="h-2 w-2 animate-pulse rounded-full bg-emerald"/> مساحة الأسواق</div><h1 className="text-2xl font-bold sm:text-3xl">صباح الأسواق، <span className="text-emerald">أهلاً بك</span></h1><p className="mt-2 text-sm text-muted">كل ما تحتاجه لقراءة السوق واتخاذ قرار أكثر وعيًا.</p></div>
   <div className="flex flex-wrap gap-2"><Link href="/ai-lab" className="btn btn-primary"><Sparkles size={16}/> مختبر الذكاء الاصطناعي</Link><Link href="/gold" className="btn"><Gem size={16}/> تحليل الذهب</Link></div>
  </div>
  <ProviderStatus />
  <div className="mb-5 flex items-start gap-3 rounded-xl border border-amber-300/20 bg-amber-300/5 p-3 text-xs leading-6 text-amber-100"><CircleHelp size={17} className="mt-1 shrink-0"/><div><b>بيئة عرض أولية:</b> بطاقات الأسعار والرسوم المصغرة ما زالت بيانات نموذجية. لن تظهر كبيانات مباشرة حتى يتم تفعيل المزود والتحقق من الأسعار.</div></div>
  <div className="mb-8 grid grid-cols-2 gap-3 xl:grid-cols-4">{[
   ["الأصول تحت المتابعة","11","قائمة مراقبة أولية",TrendingUp],["اتجاه السوق","متباين","تحتاج الأصول إلى قراءة منفصلة",BarChart3],["الأحداث القادمة","03","عرض تجريبي للتقويم",Clock3],["إدارة المخاطر","جاهزة","حاسبة المخاطرة متاحة",ShieldCheckIcon]
  ].map(([label,value,sub,Icon]:any)=><div className="panel p-4" key={label}><div className="mb-3 flex items-center justify-between"><span className="text-xs text-muted">{label}</span><Icon size={17} className="text-emerald"/></div><div className="text-2xl font-bold">{value}</div><div className="mt-1 text-[11px] text-muted">{sub}</div></div>)}</div>
  <section id="markets" className="mb-8">
   <div className="mb-4 flex items-center justify-between"><div><h2 className="text-lg font-bold">نظرة عامة على الأسواق</h2><p className="mt-1 text-xs text-muted">الأصول الأكثر متابعة · قيم توضيحية</p></div><button className="btn text-xs">كل الأسواق <ChevronLeft size={15}/></button></div>
   <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{assets.map(a=><div key={a.symbol} className="panel group p-4 transition hover:border-emerald/30"><div className="flex items-start justify-between"><div><div className="font-semibold">{a.name}</div><div className="mt-1 text-xs text-muted">{a.symbol}</div></div><button className="text-lg text-muted hover:text-amber-200" aria-label="إضافة للمفضلة">☆</button></div><div className="mt-4 flex items-end justify-between"><div><div className="text-xl font-bold tracking-tight">{a.price}</div><div className={`mt-1 text-xs font-semibold ${a.up?"positive":"negative"}`}>{a.change} <span className="font-normal text-muted">اليوم</span></div></div><div className={`text-2xl tracking-widest ${a.up?"positive":"negative"}`}>{a.spark}</div></div><div className="mt-4 flex items-center justify-between border-t border-white/5 pt-3 text-[10px] text-muted"><span>آخر تحديث: بيانات نموذجية</span><Link href={a.symbol==="XAU/USD"?"/gold":"/#charts"} className="flex items-center gap-1 text-emerald">الرسم البياني <ArrowUpLeft size={13}/></Link></div></div>)}</div>
  </section>
  <div className="mb-8 grid gap-5 xl:grid-cols-[1.55fr_1fr]">
   <section id="charts" className="panel p-4 sm:p-5"><div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><div className="text-xs text-muted">الرسم البياني · توضيحي</div><h2 className="mt-1 text-lg font-bold">الذهب مقابل الدولار <span className="text-sm font-normal text-muted">XAU/USD</span></h2></div><div className="flex gap-1">{["15د","1س","4س","1ي"].map(t=><button key={t} className={`rounded-lg px-3 py-2 text-xs ${t==="1س"?"bg-emerald text-[#04140f]":"bg-white/5 text-muted"}`}>{t}</button>)}</div></div><MarketChart/><div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted"><span>شموع توضيحية مولدة محليًا</span><Link href="/gold" className="flex items-center gap-1 text-emerald">فتح صفحة الذهب <ChevronLeft size={14}/></Link></div></section>
   <section className="panel p-5"><div className="mb-4 flex items-center justify-between"><div><h2 className="text-lg font-bold">رادار الأخبار</h2><p className="mt-1 text-xs text-muted">محتوى تجريبي غير مباشر</p></div><Newspaper className="text-emerald" size={20}/></div><div className="space-y-4">{news.map((n,i)=><div key={n.title} className="border-b border-white/5 pb-4 last:border-0"><div className="mb-2 flex items-center justify-between"><span className={`text-xs ${n.color}`}>{n.tag}</span><span className="text-[10px] text-muted">{n.time}</span></div><p className="text-sm leading-6">{n.title}</p><div className="mt-2 text-[10px] text-muted">مصدر الخبر: غير مربوط بعد</div></div>)}</div><Link href="/news" className="btn mt-1 w-full text-xs">الانتقال إلى مركز الأخبار <ChevronLeft size={15}/></Link></section>
  </div>
  <div className="grid gap-5 lg:grid-cols-3">
   <section id="signals" className="panel p-5"><div className="mb-4 flex items-center gap-2"><Activity size={18} className="text-emerald"/><h3 className="font-bold">قراءة المؤشرات</h3></div><div className="mb-3 flex items-center justify-between"><span className="text-sm">XAU/USD · ساعة</span><span className="rounded-full bg-amber-300/10 px-2.5 py-1 text-xs text-amber-200">انتظار</span></div><p className="text-xs leading-6 text-muted">لا توجد إشارة حقيقية في هذه النسخة. سيتم تفعيل التقييم عند ربط بيانات السوق ومحرك قواعد قابل للتفسير.</p><div className="mt-4 h-2 overflow-hidden rounded-full bg-white/5"><div className="h-full w-1/2 rounded-full bg-amber-300"/></div><div className="mt-2 flex justify-between text-[10px] text-muted"><span>هبوط</span><span>محايد</span><span>صعود</span></div></section>
   <section id="calendar" className="panel p-5"><div className="mb-4 flex items-center gap-2"><Clock3 size={18} className="text-amber-200"/><h3 className="font-bold">التقويم الاقتصادي</h3></div>{[["15:30","بيانات التضخم","USD","عالٍ"],["17:00","ثقة المستهلك","USD","متوسط"],["21:00","تصريحات البنك المركزي","USD","عالٍ"]].map(e=><div key={e[1]} className="mb-3 flex items-center gap-3 text-xs"><span className="rounded-md bg-white/5 px-2 py-2 font-mono text-muted">{e[0]}</span><div className="min-w-0 flex-1"><div>{e[1]}</div><div className="mt-1 text-[10px] text-muted">{e[2]} · توقيت تجريبي</div></div><span className={e[3]==="عالٍ"?"text-amber-200":"text-muted"}>{e[3]}</span></div>)}<p className="mt-3 text-[10px] text-muted">الأحداث أعلاه أمثلة واجهة وليست جدولًا فعليًا.</p></section>
   <section id="risk" className="panel p-5"><div className="mb-4 flex items-center gap-2"><Wallet size={18} className="text-emerald"/><h3 className="font-bold">أدوات المتداول</h3></div><div className="space-y-2"><Link href="/risk" className="flex items-center justify-between rounded-xl bg-white/[.03] p-3 text-sm hover:bg-white/[.06]"><span>حاسبة حجم الصفقة</span><ChevronLeft size={15} className="text-muted"/></Link><Link href="/indicators" className="flex items-center justify-between rounded-xl bg-white/[.03] p-3 text-sm hover:bg-white/[.06]"><span>مختبر المؤشرات الفنية RSI وMACD</span><ChevronLeft size={15} className="text-muted"/></Link><Link href="/ai-lab" className="flex items-center justify-between rounded-xl bg-white/[.03] p-3 text-sm hover:bg-white/[.06]"><span>تحليل صورة رسم بياني</span><ChevronLeft size={15} className="text-muted"/></Link><Link href="/gold" className="flex items-center justify-between rounded-xl bg-white/[.03] p-3 text-sm hover:bg-white/[.06]"><span>لوحة تحليل الذهب</span><ChevronLeft size={15} className="text-muted"/></Link></div></section>
  </div>
 </Shell>;
}
function ShieldCheckIcon(props:any){return <BellRing {...props}/>;}
