"use client";
import { useEffect, useState } from "react";
import { RadioTower, ShieldAlert } from "lucide-react";

type Status = { configured: boolean; provider: string | null; message: string };
export default function ProviderStatus() {
  const [status, setStatus] = useState<Status | null>(null);
  useEffect(() => { fetch("/api/market/status", { cache: "no-store" }).then(r => r.json()).then(setStatus).catch(() => setStatus({ configured: false, provider: null, message: "تعذر التحقق من حالة مزود البيانات." })); }, []);
  return <div className={`mb-5 flex items-start gap-3 rounded-xl border p-3 text-xs leading-6 ${status?.configured ? "border-emerald/20 bg-emerald/5 text-emerald-100" : "border-amber-300/20 bg-amber-300/5 text-amber-100"}`}>
    {status?.configured ? <RadioTower size={17} className="mt-1 shrink-0"/> : <ShieldAlert size={17} className="mt-1 shrink-0"/>}
    <div><b>{status?.configured ? `مزود الأسعار: ${status.provider}` : "الأسعار المباشرة غير مفعّلة"}</b><div>{status?.message || "جارٍ التحقق من إعدادات مزود البيانات..."}</div></div>
  </div>;
}
