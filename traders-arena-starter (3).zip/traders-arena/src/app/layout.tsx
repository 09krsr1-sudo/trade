import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "ساحة المتداولين | Traders Arena",
  description: "منصة عربية لتحليل الأسواق وإدارة المخاطر",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}