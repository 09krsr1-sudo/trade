export type Candle = { time: number; open: number; high: number; low: number; close: number };

export function ema(values: number[], period: number): Array<number | null> {
  if (!Number.isInteger(period) || period < 1) throw new Error("period must be a positive integer");
  const result: Array<number | null> = Array(values.length).fill(null);
  if (values.length < period) return result;
  const seed = values.slice(0, period).reduce((sum, n) => sum + n, 0) / period;
  result[period - 1] = seed;
  const alpha = 2 / (period + 1);
  let previous = seed;
  for (let i = period; i < values.length; i++) {
    previous = values[i] * alpha + previous * (1 - alpha);
    result[i] = previous;
  }
  return result;
}

export function sma(values: number[], period: number): Array<number | null> {
  const result: Array<number | null> = Array(values.length).fill(null);
  if (!Number.isInteger(period) || period < 1 || values.length < period) return result;
  let total = 0;
  for (let i = 0; i < values.length; i++) {
    total += values[i];
    if (i >= period) total -= values[i - period];
    if (i >= period - 1) result[i] = total / period;
  }
  return result;
}

export function rsi(values: number[], period = 14): Array<number | null> {
  const result: Array<number | null> = Array(values.length).fill(null);
  if (!Number.isInteger(period) || period < 1 || values.length <= period) return result;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const delta = values[i] - values[i - 1];
    if (delta > 0) gains += delta; else losses -= delta;
  }
  let avgGain = gains / period, avgLoss = losses / period;
  result[period] = avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const delta = values[i] - values[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(delta, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-delta, 0)) / period;
    result[i] = avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return result;
}

export function macd(values: number[]): { line: Array<number | null>; signal: Array<number | null>; histogram: Array<number | null> } {
  const fast = ema(values, 12), slow = ema(values, 26);
  const line: Array<number | null> = values.map((_, i) => fast[i] == null || slow[i] == null ? null : fast[i]! - slow[i]!);
  const validStart = line.findIndex(v => v !== null);
  if (validStart < 0) return { line, signal: Array(values.length).fill(null), histogram: Array(values.length).fill(null) };
  const compact = line.slice(validStart).map(v => v ?? 0);
  const compactSignal = ema(compact, 9);
  const signal: Array<number | null> = Array(values.length).fill(null);
  const histogram: Array<number | null> = Array(values.length).fill(null);
  if (validStart >= 0) {
    for (let i = 0; i < compact.length; i++) {
      const idx = validStart + i;
      if (compactSignal[i] !== null) {
        signal[idx] = compactSignal[i];
        histogram[idx] = (line[idx] ?? 0) - compactSignal[i]!;
      }
    }
  }
  return { line, signal, histogram };
}

// Deterministic sample candles for interface development only. Not market data.
export function makeSampleCandles(count = 160, base = 2640): Candle[] {
  const start = Math.floor(Date.now() / 60_000) * 60 - count * 3600;
  let price = base;
  return Array.from({ length: count }, (_, i) => {
    const open = price;
    const drift = Math.sin(i * 0.21) * 0.7 + Math.cos(i * 0.067) * 0.55 + Math.sin(i * 0.73) * 0.22;
    const close = Math.max(0.01, open + drift);
    const high = Math.max(open, close) + 0.15 + (i % 4) * 0.08;
    const low = Math.min(open, close) - 0.12 - (i % 3) * 0.06;
    price = close;
    return { time: start + i * 3600, open, high, low, close };
  });
}
