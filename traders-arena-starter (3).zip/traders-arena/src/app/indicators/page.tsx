"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import Shell from "@/components/Shell";
import { ema, macd, makeSampleCandles, rsi, sma } from "@/lib/indicators";
import { Activity, ArrowLeft, BarChart3, CircleAlert, Gauge, Waves } from "lucide-react";

const fmt = (n: number | null | undefined, digits = 2) => n == null || !Number.isFinite(n) ? "—" : n.toLocaleString("en-US", { maximumFractionDigits: digits, minimumFractionDigits: digits });
export default function IndicatorsPage() {
  const [asset, setAsset] = useState("XAU/USD");
  const [period, setPeriod] = useState("1H");
  const candles = useMemo(() => makeSampleCandles(180, asset === "EUR/USD" ? 1.084 : asset === "BTC/USD" ? 67420 : 2640), [asset]);
  const values = candles.map(c => c.close);
  const analysis = useMemo(() => {
    const e20 = ema(values, 20), e50 = ema(values, 50), simple20 = sma(values, 20), rs = rsi(values, 14), m = macd(values);
    const last = values.length - 1, rsiNow = rs[last], macdNow = m.histogram[last];
    const trend = e20[last] != null && e50[last] != null ? (e20[last]! > e50[last]! ? "صاعد" : e20[last]! < e50[last]! ? "هابط" : "محايد") : "غير متاح";
    const momentum = rsiNow == null ? "غير متاح" : rsiNow >= 70 ? "تشبع شرائي محتمل" : rsiNow <= 30 ? "تشبع بيعي محتمل" : rsiNow >= 55 ? "زخم إيجابي" : rsiNow <= 45 ? "زخم سلبي" : "زخم محايد";
    return { close: values[last], ema20: e20[last], ema50: e50[last], sma20: simple20[last], rsi: rsiNow, macd: m.line[last], signal: m.signal[last], histogram: macdNow, trend, momentum };
  }, [candles]);
  const trendColor = analysis.trend === "صاعد" ? "text-emerald" : analysis.trend === "هابط" ? "text-rose-300" : "text-amber-200";
  return <Shell>
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-3"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald/10 text-emerald"><Activity/></div><div><p className="text-xs text-emerald">TECHNICAL ANALYSIS</p><h1 className="text-2xl font-bold">مختبر المؤشرات الفنية</h1><p className="mt-1 text-sm text-muted">حساب فعلي للمؤشرات على سلسلة شموع تجريبية محلية</p></div></div><Link href="/gold" className="btn text-xs">العودة لتحليل الذهب <ArrowLeft size={14}/></Link></div>
    <div className="mb-5 flex items-center gap-3 rounded-xl border border-amber-300/20 bg-amber-300/5 p-3 text-xs leading-6 text-amber-100"><CircleAlert size={17} className="shrink-0"/><span>تنبيه مهم: المؤشرات محسوبة برمجيًا، لكن الشموع المستخدمة مولدة محليًا وليست أسعار سوق حقيقية. لا تستخدم النتائج لاتخاذ قرار تداول.</span></div>
    <section className="panel mb-5 p-4"><div className="flex flex-wrap items-end gap-4"><label className="text-sm text-muted">الأصل<select className="field mt-2 min-w-40" value={asset} onChange={e=>setAsset(e.target.value)}><option>XAU/USD</option><option>EUR/USD</option><option>BTC/USD</option></select></label><label className="text-sm text-muted">الإطار الزمني<select className="field mt-2 min-w-32" value={period} onChange={e=>setPeriod(e.target.value)}><option value="15M">15 دقيقة</option><option value="1H">ساعة</option><option value="4H">4 ساعات</option><option value="1D">يومي</option></select></label><div className="mr-auto text-xs text-muted">عدد الشموع: {candles.length} · الإطار المختار: {period} (واجهة فقط)</div></div></section>
    <div className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Metric icon={<BarChart3 size={17}/>} label="آخر إغلاق تجريبي" value={fmt(analysis.close, asset === "EUR/USD" ? 5 : 2)} sub={asset}/>
      <Metric icon={<Waves size={17}/>} label="RSI (14)" value={fmt(analysis.rsi, 1)} sub={analysis.momentum} color={analysis.rsi != null && (analysis.rsi >= 70 || analysis.rsi <= 30) ? "text-amber-200" : ""}/>
      <Metric icon={<Activity size={17}/>} label="اتجاه EMA 20 / 50" value={analysis.trend} sub={`EMA20: ${fmt(analysis.ema20, 3)} · EMA50: ${fmt(analysis.ema50, 3)}`} color={trendColor}/>
      <Metric icon={<Gauge size={17}/>} label="MACD histogram" value={fmt(analysis.histogram, 4)} sub={analysis.histogram == null ? "بيانات غير كافية" : analysis.histogram > 0 ? "أعلى من خط الإشارة" : analysis.histogram < 0 ? "أدنى من خط الإشارة" : "قريب من الصفر"}/>
    </div>
    <div className="grid gap-5 xl:grid-cols-2"><section className="panel p-5"><h2 className="mb-4 font-bold">المتوسطات المتحركة</h2>{[["EMA 20",analysis.ema20], ["EMA 50",analysis.ema50], ["SMA 20",analysis.sma20]].map(([name,val]:any)=><div key={name} className="flex items-center justify-between border-b border-white/5 py-4 last:border-0"><span className="text-sm text-muted">{name}</span><span className="font-mono text-sm">{fmt(val, asset === "EUR/USD" ? 5 : 3)}</span></div>)}<p className="mt-3 text-xs leading-6 text-muted">تقاطع EMA 20 وEMA 50 يعطي مقارنة اتجاهية مبسطة، وليس إشارة شراء أو بيع مستقلة.</p></section>
      <section className="panel p-5"><h2 className="mb-4 font-bold">ملخص MACD (12, 26, 9)</h2>{[["خط MACD",analysis.macd],["خط الإشارة",analysis.signal],["المدرج التكراري",analysis.histogram]].map(([name,val]:any)=><div key={name} className="flex items-center justify-between border-b border-white/5 py-4 last:border-0"><span className="text-sm text-muted">{name}</span><span className={`font-mono text-sm ${val > 0 ? "text-emerald" : val < 0 ? "text-rose-300" : ""}`}>{fmt(val, 4)}</span></div>)}<p className="mt-3 text-xs leading-6 text-muted">القيم محسوبة من أسعار الإغلاق التجريبية. لا تتضمن هذه النسخة حجم التداول أو تحققًا من مصدر بيانات.</p></section></div>
    <section className="panel mt-5 p-5"><h2 className="mb-3 font-bold">كيف تقرأ النتيجة؟</h2><div className="grid gap-3 md:grid-cols-3"><Guide title="الاتجاه" body="قارن EMA 20 مع EMA 50، ثم تحقق من بنية السعر ومستويات الدعم والمقاومة."/><Guide title="الزخم" body="RSI فوق 70 أو دون 30 قد يشير إلى زخم ممتد، لكنه لا يعني انعكاسًا حتميًا."/><Guide title="التأكيد" body="لا تعتمد على مؤشر واحد. راجع الإطار الأكبر والأخبار وإدارة المخاطر قبل أي قرار."/></div></section>
  </Shell>;
}
function Metric({icon,label,value,sub,color=""}:{icon:React.ReactNode;label:string;value:string;sub:string;color?:string}){return <div className="panel p-4"><div className="mb-3 flex items-center justify-between text-muted"><span className="text-xs">{label}</span><span className="text-emerald">{icon}</span></div><div className={`text-xl font-bold ${color}`}>{value}</div><div className="mt-2 text-[11px] text-muted">{sub}</div></div>}
function Guide({title,body}:{title:string;body:string}){return <div className="rounded-xl bg-white/[.03] p-4"><h3 className="mb-2 text-sm font-semibold text-emerald">{title}</h3><p className="text-xs leading-6 text-muted">{body}</p></div>}
