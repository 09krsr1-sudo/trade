import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const configured = Boolean(process.env.TWELVEDATA_API_KEY);
  return NextResponse.json({
    provider: configured ? "Twelve Data" : null,
    configured,
    status: configured ? "configured" : "not_configured",
    message: configured
      ? "تم إعداد مفتاح مزود البيانات. تحقق من استجابة الأسعار قبل الاعتماد عليها."
      : "لم يتم إعداد مزود أسعار مباشر. المعروض في الواجهة بيانات توضيحية فقط.",
  });
}
