"use client";
import { useState } from "react";
import Link from "next/link";
import { Activity, Bell, BookOpen, Bot, CandlestickChart, ChevronDown, CircleDollarSign, Clock3, Compass, Gauge, Gem, Globe2, Home, Menu, Newspaper, Search, Settings, ShieldCheck, Wallet, X } from "lucide-react";

const links = [
  ["الرئيسية","/",Home],["الأسواق","#markets",Globe2],["الرسوم البيانية","#charts",CandlestickChart],["الذهب","/gold",Gem],["المؤشرات الفنية","/indicators",Activity],
  ["الفوركس","#markets",CircleDollarSign],["الأسهم","#markets",Activity],["العملات الرقمية","#markets",Compass],["الأخبار","/news",Newspaper],
  ["مختبر الذكاء الاصطناعي","/ai-lab",Bot],["إشارات السوق","#signals",Gauge],["التقويم الاقتصادي","#calendar",Clock3],
  ["إدارة المخاطر","#risk",ShieldCheck],["المحفظة الافتراضية","#portfolio",Wallet],["أكاديمية التداول","#academy",BookOpen],["الإعدادات","#settings",Settings]
] as const;

export default function Shell({children}: {children: React.ReactNode}) {
 const [open,setOpen]=useState(false);
 return <div className="min-h-screen">
  <header className="sticky top-0 z-30 border-b border-white/5 bg-[#07111f]/90 backdrop-blur-xl">
   <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-4 px-4 py-3 lg:px-7">
    <div className="flex items-center gap-3">
     <button className="btn lg:hidden" onClick={()=>setOpen(!open)} aria-label="فتح القائمة">{open?<X size={18}/>:<Menu size={18}/>}</button>
     <Link href="/" className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald text-[#04140f]"><CandlestickChart size={23}/></div><div><div className="font-bold tracking-wide">ساحة المتداولين</div><div className="text-[10px] uppercase tracking-[.2em] text-emerald">TRADERS ARENA</div></div></Link>
    </div>
    <div className="hidden max-w-md flex-1 md:flex"><div className="flex w-full items-center gap-2 rounded-xl border border-white/10 bg-panel px-3"><Search size={17} className="muted"/><input className="w-full bg-transparent py-2.5 text-sm outline-none" placeholder="ابحث عن أصل أو خبر أو تحليل..." /></div></div>
    <div className="flex items-center gap-2"><span className="hidden rounded-lg border border-amber-300/20 bg-amber-300/10 px-3 py-2 text-xs text-amber-200 sm:inline">وضع تجريبي</span><button className="btn relative" aria-label="التنبيهات"><Bell size={18}/><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-emerald"/></button><button className="btn"><span className="grid h-6 w-6 place-items-center rounded-full bg-emerald/20 text-xs text-emerald">ك</span><span className="hidden sm:inline">حسابي</span><ChevronDown size={14}/></button></div>
   </div>
  </header>
  <div className="mx-auto flex max-w-[1600px]">
   <aside className={`${open?"fixed inset-y-0 right-0 z-40 block w-72 overflow-y-auto border-l border-white/10 bg-[#091523] pt-20":"hidden"} w-64 shrink-0 p-4 lg:sticky lg:top-[66px] lg:block lg:h-[calc(100vh-66px)] lg:overflow-y-auto`}>
    <div className="mb-3 px-3 text-[11px] font-bold tracking-wider text-muted">مساحة العمل</div>
    <nav className="space-y-1">{links.map(([label,href,Icon],i)=><Link key={label} href={href} onClick={()=>setOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-white/5 ${i===0?"bg-emerald/10 font-semibold text-emerald": "text-slate-300"}`}><Icon size={17}/><span>{label}</span></Link>)}</nav>
    <div className="panel mt-6 p-4"><div className="mb-2 flex items-center gap-2 text-sm font-semibold"><Bot size={17} className="text-emerald"/> مساعد الساحة</div><p className="text-xs leading-6 text-muted">حلّل السوق، افهم الأخبار، ونظّم مخاطرتك في مكان واحد.</p><Link href="/ai-lab" className="mt-3 block rounded-lg bg-emerald px-3 py-2 text-center text-xs font-bold text-[#04140f]">ابدأ التحليل</Link></div>
   </aside>
   {open&&<button className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={()=>setOpen(false)} aria-label="إغلاق القائمة"/>}
   <main className="min-w-0 flex-1 px-4 py-6 lg:px-7">{children}<footer className="mt-10 border-t border-white/5 py-5 text-center text-xs leading-6 text-muted">ساحة المتداولين — البيانات المعروضة في هذه النسخة توضيحية وليست أسعارًا مباشرة أو توصية استثمارية.</footer></main>
  </div>
 </div>
}